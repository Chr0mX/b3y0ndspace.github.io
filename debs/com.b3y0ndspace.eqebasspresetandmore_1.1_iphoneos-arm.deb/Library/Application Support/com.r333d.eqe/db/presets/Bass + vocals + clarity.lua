return {
    {
        name = "preamp",
        gain = 0.61810201406479,
    },
    {
        name = "eq",
        frequency = 31,
        Q = 1,
        gain = 10.5,
    },
    {
        name = "eq",
        frequency = 60,
        Q = 1,
        gain = 5.887558,
    },
    {
        name = "eq",
        frequency = 170,
        Q = 1,
        gain = 2.129635,
    },
    {
        name = "eq",
        frequency = 310,
        Q = 1,
        gain = 0.013265,
    },
    {
        name = "eq",
        frequency = 600,
        Q = 1,
        gain = -3.267516,
    },
    {
        name = "eq",
        frequency = 1000,
        Q = 1,
        gain = -7.617009,
    },
    {
        name = "eq",
        frequency = 3000,
        Q = 1,
        gain = -9.206359,
    },
    {
        name = "eq",
        frequency = 6000,
        Q = 1,
        gain = 6.0,
    },
    {
        name = "eq",
        frequency = 12000,
        Q = 2,
        gain = -15.752373,
    },
    {
        name = "eq",
        frequency = 14000,
        Q = 2,
        gain = 1.147259,
    },
    {
        name = "eq",
        frequency = 16000,
        Q = 2,
        gain = 6.198936,
    },
}